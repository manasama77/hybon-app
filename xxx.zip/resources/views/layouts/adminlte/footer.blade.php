<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        v {{ env('APP_VER') }}
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2024 <a href="#">Sistegra Emran Sentosa</a>.</strong> All rights reserved.
</footer>
