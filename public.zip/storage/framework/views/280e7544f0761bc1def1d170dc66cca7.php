

<img src="<?php echo e(asset('img/logo.png')); ?>" alt="<?php echo e(env('APP_NAME')); ?>" <?php echo e($attributes); ?>>
<?php /**PATH D:\laragon\www\app.carbon\resources\views/components/application-logo.blade.php ENDPATH**/ ?>