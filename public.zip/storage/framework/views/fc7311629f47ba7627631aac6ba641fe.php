<?php $__env->startSection('isi_aku_mas'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($page_title); ?></h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-4 offset-md-4">
                        <form action="<?php echo e(route('user-management.proses-reset-password', $data->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><?php echo e($page_title); ?></h3>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="username">Username</label>
                                        <input type="text" class="form-control" id="username" name="username"
                                            value="<?php echo e($data->username); ?>" readonly />
                                        <?php if($errors->has('username')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="password">New Password</label>
                                        <input type="password" class="form-control" id="password" name="password"
                                            required />
                                        <?php if($errors->has('password')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="password_confirmation">Password Confirmation</label>
                                        <input type="password" class="form-control" id="password_confirmation"
                                            name="password_confirmation" required />
                                        <?php if($errors->has('password_confirmation')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="card-footer d-flex justify-content-end">
                                    <a href="<?php echo e(route('user-management')); ?>" class="btn btn-dark mr-1">
                                        <i class="fa-solid fa-backward"></i> Kembali
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa-solid fa-save fa-fw"></i> Simpan
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aku_jawa'); ?>
    <script>
        $(document).ready(function() {})
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app.carbon\resources\views/pages/user-management/reset_password.blade.php ENDPATH**/ ?>