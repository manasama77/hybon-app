<?php $__env->startSection('isi_aku_mas'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($page_title); ?></h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-4 offset-md-4">
                        <form action="<?php echo e(route('data-reference.tipe-barang.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><?php echo e($page_title); ?></h3>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="name">Nama Tipe Barang</label>
                                        <input type="text" class="form-control" id="name" name="name"
                                            value="<?php echo e(old('name')); ?>" required />
                                        <?php if($errors->has('name')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="card-footer d-flex justify-content-end">
                                    <a href="<?php echo e(route('data-reference.tipe-barang')); ?>" class="btn btn-dark mr-1">
                                        <i class="fa-solid fa-backward"></i> Kembali
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa-solid fa-save fa-fw"></i> Simpan
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aku_jawa'); ?>
    <script>
        $(document).ready(function() {})
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app.carbon\resources\views/pages/data-reference/tipe-barang/form.blade.php ENDPATH**/ ?>