<?php $__env->startSection('isi_aku_mas'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($page_title); ?></h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-4 offset-md-4">
                        <form action="<?php echo e(route('warehouse.master-barang.update', $datas->id)); ?>" method="post">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>


                            <?php echo csrf_field(); ?>
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><?php echo e($page_title); ?></h3>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="nama_barang">Nama Barang</label>
                                        <input type="text" class="form-control" id="nama_barang" name="nama_barang"
                                            value="<?php echo e(old('nama_barang') ?? $datas->nama_barang); ?>" required />
                                        <?php if($errors->has('nama_barang')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('nama_barang')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="tipe_barang_id">Tipe Barang</label>
                                        <select class="form-control" id="tipe_barang_id" name="tipe_barang_id" required>
                                            <option value=""></option>
                                            <?php $__currentLoopData = $tipe_barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipe_barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if($datas->tipe_barang_id == $tipe_barang->id): echo 'selected'; endif; ?> value="<?php echo e($tipe_barang->id); ?>">
                                                    <?php echo e($tipe_barang->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('tipe_barang_id')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('tipe_barang_id')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="nama_vendor">Nama Vendor</label>
                                        <input type="text" class="form-control" id="nama_vendor" name="nama_vendor"
                                            value="<?php echo e(old('nama_vendor') ?? $datas->nama_vendor); ?>" required />
                                        <?php if($errors->has('nama_vendor')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('nama_vendor')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="tipe_stock">Tipe Stock</label>
                                        <select class="form-control" id="tipe_stock" name="tipe_stock" required>
                                            <option <?php if($datas->tipe_stock == 'satuan'): echo 'selected'; endif; ?> value="satuan">Satuan</option>
                                            <option <?php if($datas->tipe_stock == 'lembar'): echo 'selected'; endif; ?> value="lembar">Lembar</option>
                                        </select>
                                        <?php if($errors->has('tipe_stock')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('tipe_stock')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="satuan">Nama Satuan</label>
                                        <input type="text" class="form-control" id="satuan" name="satuan"
                                            value="<?php echo e(old('satuan') ?? $datas->satuan); ?>" required />
                                        <?php if($errors->has('satuan')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('satuan')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="card-footer d-flex justify-content-end">
                                    <a href="<?php echo e(route('warehouse.master-barang')); ?>" class="btn btn-dark mr-1">
                                        <i class="fa-solid fa-backward"></i> Kembali
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa-solid fa-save fa-fw"></i> Simpan
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aku_jawa'); ?>
    <script>
        $(document).ready(function() {})
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app.carbon\resources\views/pages/warehouse/master-barang/form_edit.blade.php ENDPATH**/ ?>